<?php

$host = 'localhost';
$user = 'root';
$pass = '';
$banco = 'b33_19025458_socea';
$conexao = mysqli_connect($host, $user, $pass, $banco) or die(mysql_error());
?>
