<?php

    //Inclui o arquivo com o sistema de segurança
    require_once('Seguranca.php');

    //Verifica se um formulario foi enviado
if($_SERVER['REQUEST_METHOD']=='POST'){
    //Salva duas variaveis com o que foi digitado no formulario
    //e faz verificaçao com isset() para saber se o campo foi preenchido
    $Email =(isset($_POST['Email']))?$_POST['Email']:'';
    $senha =(isset($_POST['Senha']))?$_POST['Senha']:'';

    if(ValidaUsuario($Email, $senha)){
        //O usuario e senha validados, manda pra pagina interna
        header('Location:../Inicio.php');
    }else{
        //O usuario e senha logado manda para form de login
        ExpulsaVisitante();
    }


}?>
