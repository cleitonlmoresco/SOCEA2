<?php

$Versao = "BETA 00.6";