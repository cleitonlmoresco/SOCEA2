
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>SOCEA</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<!-- templatemo 329 blue urban -->
<!-- 
Blue Urban Template 
http://www.templatemo.com/preview/templatemo_329_blue_urban
-->
<link href="templatemo_style.css" rel="stylesheet" type="text/css" />

</head>
<body>

<div id="templatemo_wrapper">
	
    <div id="templatemo_header">
    
   		<div id="site_title">
            <h1><a href="#">SOCEA</span></a></h1>
        </div> <!-- end of site_title -->
       
    </div>
    
    <div id="templatemo_middle">
    
    	<h1>SOCEA</h1>
        <p>Sistema de Organização e Cobrança de 
Escritório de Advocacia.</p>
        
    
    </div>
    
    <div id="templatemo_content">
    
    	<div class="col_w300">
		
            
            <div class="image_wrapper"></div>
          	
               
                    
        </div>
    
        <div class="col_w300">
		
            <h3><Center>Efetue o seu Login.</Center></h3>
          	      
            <form action="Scripts/Valida.php" method="post" name="Login">
                <p><center>E-mail</center></p>
                      <center> &nbsp;<input size="30" name="Email" type="text">&nbsp;
                              <p>&nbsp;Senha</p><br>
                        <p style="margin-top: -17px; margin-left: 6px;"> <input
                            size="15" name="Senha" type="password"></p>
                        <p><a href="%20">Esqueci
                            senha 
                                <p><a href="%20">Alterar senha.<br></br>
                          </a></p>
                        <input value="Entrar" id="Entrar" name="Entrar" type="submit">
                    
            
      </center></form>
			
            <div class="cleaner"></div>
	</div><div class="cleaner"></div>
    </div>
    
    <div id="templatemo_footer">
    
    	  <?php include 'Scripts/Versao.php'; ?>
    	 <a href="#">SOCEA </a> V. <?php echo $Versao;?>
         
    </div>
    
</div>

</body>
</html>